﻿//
//  UnityBridge.mm 鈥斺€?鎶?hook 鍒扮殑鐞冭〃杞垚鍙粯鍒剁殑瀹炰綋
//
//  娓告垙鍧愭爣 -> 灞忓箷鍧愭爣鐨勬崲绠楋細
//    鐞冪悆澶т綔鎴樻槸 2D 淇锛孉ddBall/MoveBall 缁欑殑鏄父鎴忎笘鐣屽潗鏍囷紙鏁存暟锛夈€?//    AUG_SCALE 鍏堟妸涓栫晫鍧愭爣鍘嬪埌灞忓箷锛氬睆骞曞昂瀵?/ 瑙嗛噹鍗婂緞銆?//    瑙嗛噹鍗婂緞浼氶殢鍒嗘暟鍙樺寲锛岃繖閲岀敤鍥哄畾鍊?+ 缁忛獙绯绘暟锛屽疄娴嬪彲寰皟銆?//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include "UnityBridge.h"
#include "ModuleControl.h"

// 涓栫晫鍗曚綅 -> 灞忓箷鍍忕礌鐨勭缉鏀撅紙鎸夋満鍨?瑙嗛噹瀹炴祴寰皟锛?static float gScale = 0.35f;
// 鑷韩鐞冨湪灞忓箷涓婄殑鍥哄畾浣嶇疆锛堜竴鑸睆骞曚笂鍋忎笅灞呬腑锛?static CGPoint gSelfScreen = {0, 0};
static int gSelfUserID = -1;

int AUGUnityInit(void) {
    return AUGInstallBallHooks();
}

int AUGCollectEntities(AUGEntity *out, int maxCount) {
    BallRec balls[AUG_MAX_ENTITIES];
    int n = AUGCopyBalls(balls, AUG_MAX_ENTITIES);

    CGRect scr = [UIScreen mainScreen].bounds;
    if (gSelfScreen.x == 0 && gSelfScreen.y == 0) {
        gSelfScreen = CGPointMake(scr.size.width * 0.5, scr.size.height * 0.55);
    }

    int m = 0;
    for (int i = 0; i < n && m < maxCount; i++) {
        BallRec *b = &balls[i];
        if (b->score <= 0) continue;
        if (b->userid == gSelfUserID) continue;      // 涓嶇敾鑷繁

        // 鍒嗘暟 -> 鍗婂緞锛堥潰绉姣斾簬鍒嗘暟锛?        float r = sqrtf((float)b->score) * 0.55f;
        // 涓栫晫鍧愭爣 -> 灞忓箷鍧愭爣
        float sx = gSelfScreen.x + (b->x - balls[0].x) * gScale;
        float sy = gSelfScreen.y + (b->y - balls[0].y) * gScale;

        AUGEntity *e = &out[m++];
        memset(e, 0, sizeof(*e));
        e->wx = b->x;
        e->wy = b->y;
        e->screen_x = sx;
        e->screen_y = sy;
        e->radius = r * gScale * 2.0f;
        e->score = b->score;
        e->visible = (sx > -100 && sy > -100 && sx < scr.size.width + 100 && sy < scr.size.height + 100);
        snprintf(e->name, sizeof(e->name), "%d", b->score);
    }
    return m;
}

int AUGWorldToScreen(float wx, float wy, float wz, AUGPoint *out) {
    (void)wz;
    out->x = gSelfScreen.x + wx * gScale;
    out->y = gSelfScreen.y + wy * gScale;
    return 1;
}

void AUGAimAt(const AUGEntity *e, float speed) {
    if (!e) return;
    // 2D 娓告垙锛氭妸瑙︽懜鐐瑰線鐩爣鏂瑰悜鎺紙鐢变笂灞傚喅瀹氭槸鍚﹁皟鐢級
    (void)speed;
}
