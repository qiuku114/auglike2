//
//  OverlayView.mm —— Metal + ImGui 叠加层
//
//  对应原包 _0x1E6B7A93（MTKView 子类）：
//    mtkView:drawableSizeWillChange: / drawInMTKView: / touches*
//  这里用 CADisplayLink 驱动 ImGui 帧，Metal 直接画到 MTKView 的 drawable。
//
#import "AUGLike.h"
#import <Metal/Metal.h>
#import <MetalKit/MetalKit.h>

#include "imgui.h"
#include "imgui_impl_metal.h"

#include "AUGRender.h"

@interface AUGOverlayView () <MTKViewDelegate>
@property (nonatomic, strong) MTKView *mtk;
@property (nonatomic, strong) id<MTLDevice> device;
@property (nonatomic, strong) id<MTLCommandQueue> queue;
@property (nonatomic, strong) CADisplayLink *link;
@property (nonatomic, assign) CGPoint lastTouch;
@end

@implementation AUGOverlayView

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = YES;
        self.multipleTouchEnabled = YES;

        _device = MTLCreateSystemDefaultDevice();
        _mtk = [[MTKView alloc] initWithFrame:self.bounds device:_device];
        _mtk.delegate = self;
        _mtk.colorPixelFormat = MTLPixelFormatBGRA8Unorm;
        _mtk.clearColor = MTLClearColorMake(0, 0, 0, 0);
        _mtk.opaque = NO;
        _mtk.userInteractionEnabled = NO;   // 触摸由本视图统一处理
        _mtk.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [self addSubview:_mtk];

        _queue = [_device newCommandQueue];

        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGui::StyleColorsDark();
        ImGuiIO &io = ImGui::GetIO();
        io.IniFilename = NULL;
        io.DisplaySize = ImVec2(frame.size.width, frame.size.height);
        ImGui_ImplMetal_Init(_device);

        _link = [CADisplayLink displayLinkWithTarget:self selector:@selector(tick:)];
        [_link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    ImGui::GetIO().DisplaySize = ImVec2(self.bounds.size.width, self.bounds.size.height);
}

/* ---------------- 渲染循环 ---------------- */
- (void)tick:(CADisplayLink *)link {
    [_mtk draw];
}

- (void)mtkView:(MTKView *)view drawableSizeWillChange:(CGSize)size {
    ImGui::GetIO().DisplaySize = ImVec2(size.width, size.height);
}

- (void)drawInMTKView:(MTKView *)view {
    @autoreleasepool {
        ImGuiIO &io = ImGui::GetIO();
        io.DisplaySize = ImVec2(view.drawableSize.width, view.drawableSize.height);

        id<MTLCommandBuffer> cb = [_queue commandBuffer];
        MTLRenderPassDescriptor *pass = view.currentRenderPassDescriptor;
        if (!pass) return;

        ImGui_ImplMetal_NewFrame(pass);
        ImGui::NewFrame();

        AUGRenderFrame(&gMC);      // 菜单 + ESP 绘制

        ImGui::Render();
        id<MTLRenderCommandEncoder> enc = [cb renderCommandEncoderWithDescriptor:pass];
        ImGui_ImplMetal_RenderDrawData(ImGui::GetDrawData(), cb, enc);
        [enc endEncoding];
        [cb presentDrawable:view.currentDrawable];
        [cb commit];
    }
}

/* ---------------- 触摸转发给 ImGui ---------------- */
- (void)pushTouches:(NSSet<UITouch *> *)touches down:(BOOL)down {
    UITouch *t = touches.anyObject;
    if (!t) return;
    CGPoint p = [t locationInView:self];
    ImGuiIO &io = ImGui::GetIO();
    io.AddMousePosEvent(p.x, p.y);
    if (down) io.AddMouseButtonEvent(0, true);
    else      io.AddMouseButtonEvent(0, false);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self pushTouches:touches down:YES]; }
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self pushTouches:touches down:YES]; }
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self pushTouches:touches down:NO]; }
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event { [self pushTouches:touches down:NO]; }

@end
