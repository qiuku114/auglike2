﻿//
//  main.mm 鈥斺€?dylib 鍏ュ彛锛氳绐楀彛銆佽鎮诞鐞冦€佸惎鍔ㄦ覆鏌撳惊鐜?//
//  涓庡師鍖呭樊寮傦細杩欓噷娌℃湁浠讳綍鍗″瘑/楠岀/鎺堟潈鏂囦欢閫昏緫銆?//  AUGIsLicensed() 鎭?YES锛屽姛鑳戒綅鐩存帴鍙啓銆?//
#import "AUGLike.h"
#import <objc/runtime.h>
#include <dispatch/dispatch.h>
#include "UnityBridge.h"

ModuleControl gMC = {0};

static AUGOverlayWindow *gWindow = nil;
static AUGFloatingBall  *gBall   = nil;

void AUGStartOverlay(void) {
    if (gWindow) return;

    // 1) 鍙犲姞绐楀彛锛氬眰绾ч珮浜庢父鎴忕獥鍙ｏ紝浣嗕笉鎶㈡櫘閫氳Е鎽革紙hitTest 閲屾斁琛岋級
    gWindow = [[AUGOverlayWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    gWindow.windowLevel = UIWindowLevelAlert - 1;
    gWindow.backgroundColor = [UIColor clearColor];
    gWindow.rootViewController = [UIViewController new];
    gWindow.hidden = NO;

    // 2) 娓叉煋瑙嗗浘锛圡etal + ImGui锛夛紝閾烘弧鍏ㄥ睆
    AUGOverlayView *view = [[AUGOverlayView alloc] initWithFrame:gWindow.bounds];
    view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    [gWindow.rootViewController.view addSubview:view];

    // 3) 鎮诞鐞冿細鐐瑰畠寮€鍏宠彍鍗?    gBall = [[AUGFloatingBall alloc] initWithFrame:CGRectMake(24, 160, 52, 52)];
    [gWindow.rootViewController.view addSubview:gBall];

    // 4) 榛樿寮€鍏筹紙鍘熷寘鐢卞崱瀵嗗喅瀹氾紝杩欓噷鐩存帴缁欙級
    gMC.enabled = true;
    gMC.main.a = true;      // 鑿滃崟鎬诲紑鍏?    gMC.main.b = true;      // ESP
    gMC.main.c = false;     // 鑷瀯

    // 5) 鎸傛父鎴忓師鐢熺悆浣撴帴鍙ｏ紙AddBall/MoveBall/...锛?    int rc = AUGUnityInit();
    NSLog(@"[AUGLike] ball hooks rc=%d", rc);
}

__attribute__((constructor))
static void AUGLikeInit(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        AUGStartOverlay();
    });
}
