﻿//
//  BallHook.mm 鈥斺€?hook 娓告垙鍘熺敓鐨勭悆浣撴帴鍙ｏ紝鎷垮埌瀹炴椂鍧愭爣鍜屽垎鏁?//
//  鍦板潃鏉ヨ嚜 Il2CppDumper 鐨?dump.cs锛圲nityFramework 鍐?RVA锛夛細
//    AddPlayer  0x225149C  (id, ballnum, teamid, x, y, score)
//    AddBall    0x22514A0  (userid, x, y, score)
//    DelBall    0x22514A4  (userid, ballid)
//    MoveBall   0x22514A8  (userid, ballid, x, y)
//    SetScore   0x22514BC  (ballid, score)
//
//  鍋氭硶锛氳繖浜涙槸 12 瀛楄妭鐨勫鍏ユ々锛坅drp x16,page ; ldr x16,[x16,#off] ; br x16锛夛紝
//  鎶婃々鏁翠綋鏀瑰啓鎴愯烦鍚戞垜浠嚜宸辩殑鍑芥暟锛岀瓑闀裤€佷綅缃棤鍏炽€?//  鍘熷鐩爣鍦板潃鍦ㄦ敼鍐欏墠鍏堣В鍑烘潵锛屽洖璋冮噷鍐嶈浆璋冨師鍑芥暟锛屾父鎴忛€昏緫涓嶅彈褰卞搷銆?//
#import <Foundation/Foundation.h>
#import <dlfcn.h>
#include <mach-o/dyld.h>
#include <pthread.h>
#include <string.h>
#include <stdint.h>
#include "UnityBridge.h"

#define MAX_BALLS 256

static BallRec gBalls[MAX_BALLS];
static int     gBallCount = 0;
static pthread_mutex_t gBallLock = PTHREAD_MUTEX_INITIALIZER;

/* 椋熺墿鐐逛綅 */
#define MAX_FEEDS 512
typedef struct { int x, y, score; } FeedRec;
static FeedRec gFeeds[MAX_FEEDS];
static int     gFeedCount = 0;

/* ---------------- 鍘熷鍑芥暟 ---------------- */
typedef int (*fn_add_player)(int, int, int, int, int, int);
typedef int (*fn_add_ball)(int, int, int, int);
typedef int (*fn_del_ball)(int, int);
typedef int (*fn_move_ball)(int, int, int, int);
typedef int (*fn_set_score)(int, int);

static fn_add_player gOrigAddPlayer = NULL;
static fn_add_ball   gOrigAddBall   = NULL;
static fn_del_ball   gOrigDelBall   = NULL;
static fn_move_ball  gOrigMoveBall  = NULL;
static fn_set_score  gOrigSetScore  = NULL;
typedef int (*fn_add_feed)(int, int, int, int);
typedef int (*fn_del_scene)(void);
typedef int (*fn_break)(int, int);
static fn_add_feed   gOrigAddFeed   = NULL;
static fn_del_scene  gOrigDelScene  = NULL;
static fn_break      gOrigBreak     = NULL;

/* 鍒嗚浜嬩欢锛堢粰"鍒嗚棰勮"鐢級 */
static int gLastBreaker = -1;
static int gLastBreakPct = 0;
static uint64_t gLastBreakTime = 0;

/* ---------------- 鐞冭〃缁存姢 ---------------- */
static BallRec *FindBall(int userid, int ballid) {
    for (int i = 0; i < gBallCount; i++)
        if (gBalls[i].alive && gBalls[i].userid == userid && gBalls[i].ballid == ballid)
            return &gBalls[i];
    return NULL;
}

static BallRec *NewBall(void) {
    if (gBallCount >= MAX_BALLS) return NULL;
    BallRec *b = &gBalls[gBallCount++];
    memset(b, 0, sizeof(*b));
    b->alive = 1;
    return b;
}

/* ---------------- 鎴戜滑鐨勫疄鐜?---------------- */
static int HookAddPlayer(int id, int ballnum, int teamid, int x, int y, int score) {
    pthread_mutex_lock(&gBallLock);
    BallRec *b = NewBall();
    if (b) { b->userid = id; b->ballid = ballnum; b->teamid = teamid;
             b->x = x; b->y = y; b->score = score; }
    pthread_mutex_unlock(&gBallLock);
    return gOrigAddPlayer ? gOrigAddPlayer(id, ballnum, teamid, x, y, score) : 0;
}

static int HookAddBall(int userid, int x, int y, int score) {
    pthread_mutex_lock(&gBallLock);
    BallRec *b = NewBall();
    if (b) { b->userid = userid; b->ballid = -1; b->x = x; b->y = y; b->score = score; }
    pthread_mutex_unlock(&gBallLock);
    return gOrigAddBall ? gOrigAddBall(userid, x, y, score) : 0;
}

static int HookDelBall(int userid, int ballid) {
    pthread_mutex_lock(&gBallLock);
    BallRec *b = FindBall(userid, ballid);
    if (b) b->alive = 0;
    pthread_mutex_unlock(&gBallLock);
    return gOrigDelBall ? gOrigDelBall(userid, ballid) : 0;
}

static int HookMoveBall(int userid, int ballid, int x, int y) {
    pthread_mutex_lock(&gBallLock);
    BallRec *b = FindBall(userid, ballid);
    if (!b) { b = NewBall(); if (b) { b->userid = userid; b->ballid = ballid; } }
    if (b) { b->x = x; b->y = y; }
    pthread_mutex_unlock(&gBallLock);
    return gOrigMoveBall ? gOrigMoveBall(userid, ballid, x, y) : 0;
}

static int HookSetScore(int ballid, int score) {
    pthread_mutex_lock(&gBallLock);
    for (int i = 0; i < gBallCount; i++)
        if (gBalls[i].alive && (gBalls[i].ballid == ballid || gBalls[i].userid == ballid))
            gBalls[i].score = score;
    pthread_mutex_unlock(&gBallLock);
    return gOrigSetScore ? gOrigSetScore(ballid, score) : 0;
}

static int HookAddFeed(int userid, int x, int y, int score) {
    if (gFeedCount < MAX_FEEDS) {
        gFeeds[gFeedCount].x = x;
        gFeeds[gFeedCount].y = y;
        gFeeds[gFeedCount].score = score;
        gFeedCount++;
    }
    return gOrigAddFeed ? gOrigAddFeed(userid, x, y, score) : 0;
}

static int HookDelScene(void) {
    pthread_mutex_lock(&gBallLock);
    gBallCount = 0;
    gFeedCount = 0;
    pthread_mutex_unlock(&gBallLock);
    return gOrigDelScene ? gOrigDelScene() : 0;
}

static int HookBreak(int userid, int percent) {
    gLastBreaker = userid;
    gLastBreakPct = percent;
    gLastBreakTime = mach_absolute_time();
    return gOrigBreak ? gOrigBreak(userid, percent) : 0;
}

int AUGLastBreak(int *userid, int *percent, uint64_t *when) {
    if (userid) *userid = gLastBreaker;
    if (percent) *percent = gLastBreakPct;
    if (when) *when = gLastBreakTime;
    return gLastBreaker >= 0;
}

/* ---------------- 妗╂敼鍐欏伐鍏?---------------- */
static void *StubTarget(void *stub) {
    uint32_t *p = (uint32_t *)stub;
    uint32_t adrp = p[0], ldr = p[1];
    if ((adrp & 0x9F00001F) != 0x90000010) return NULL;   // adrp x16
    if ((ldr & 0xFFC003FF) != 0xF9400210) return NULL;    // ldr x16,[x16,#imm]
    uint64_t pc = (uint64_t)stub;
    int64_t immhi = (adrp >> 5) & 0x7FFFF;
    int64_t immlo = (adrp >> 29) & 0x3;
    int64_t imm = (immhi << 2) | immlo;
    if (imm & (1 << 20)) imm -= (1 << 21);
    uint64_t page = (pc & ~0xFFFULL) + (uint64_t)(imm << 12);
    uint64_t slot = page + ((ldr >> 10) & 0xFFF) * 8;
    return *(void **)slot;
}

// 鎶婃々鏀瑰啓鎴?adrp/add/br -> fn锛?2 瀛楄妭锛屼綅缃棤鍏筹級
static void PatchStub(void *stub, void *fn) {
    uint64_t pc = (uint64_t)stub, target = (uint64_t)fn;
    int64_t delta = (int64_t)(target & ~0xFFFULL) - (int64_t)(pc & ~0xFFFULL);
    int64_t pages = delta >> 12;
    uint32_t adrp = 0x90000010u
        | (uint32_t)(((pages >> 2) & 0x7FFFF) << 5)
        | (uint32_t)(pages & 0x3) << 29;
    uint32_t lo = (uint32_t)(target & 0xFFF);
    uint32_t add = 0x91000010u | (lo << 10);   // add x16, x16, #lo
    uint32_t br  = 0xD61F0200u;                // br x16
    uint32_t *p = (uint32_t *)stub;
    p[0] = adrp; p[1] = add; p[2] = br;
    __builtin___clear_cache((char *)stub, (char *)stub + 12);
}

/* ---------------- 瀹夎 ---------------- */
static void *ImageBase(const char *name) {
    for (uint32_t i = 0; i < _dyld_image_count(); i++) {
        const char *n = _dyld_get_image_name(i);
        if (n && strstr(n, name)) return (void *)_dyld_get_image_header(i);
    }
    return NULL;
}

int AUGInstallBallHooks(void) {
    void *base = ImageBase("UnityFramework");
    if (!base) return 1;

    #define H(rva, orig, hook) do {                      \
        void *stub = (char *)base + (rva);               \
        orig = (void *)StubTarget(stub);                 \
        if (orig) PatchStub(stub, (void *)(hook));       \
    } while (0)

    H(0x2251498, gOrigDelScene,  HookDelScene)
    H(0x225149C, gOrigAddPlayer, HookAddPlayer)
    H(0x22514A0, gOrigAddBall,   HookAddBall)
    H(0x22514A4, gOrigDelBall,   HookDelBall)
    H(0x22514A8, gOrigMoveBall,  HookMoveBall)
    H(0x22514B0, gOrigAddFeed,   HookAddFeed)
    H(0x22514B8, gOrigBreak,     HookBreak)
    H(0x22514BC, gOrigSetScore,  HookSetScore)
    #undef H

    return 0;
}

/* 缁?ESP 鍙栨暟鎹?*/
int AUGCopyBalls(BallRec *out, int maxCount) {
    int n = 0;
    pthread_mutex_lock(&gBallLock);
    for (int i = 0; i < gBallCount && n < maxCount; i++)
        if (gBalls[i].alive) out[n++] = gBalls[i];
    pthread_mutex_unlock(&gBallLock);
    return n;
}

int AUGCopyFeeds(AUGFeed *out, int maxCount) {
    int n = 0;
    pthread_mutex_lock(&gBallLock);
    for (int i = 0; i < gFeedCount && n < maxCount; i++) {
        out[n].x = gFeeds[i].x;
        out[n].y = gFeeds[i].y;
        out[n].score = gFeeds[i].score;
        n++;
    }
    pthread_mutex_unlock(&gBallLock);
    return n;
}
