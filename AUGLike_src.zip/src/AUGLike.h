//
//  AUGLike.h —— 公共声明
//
#pragma once
#import <UIKit/UIKit.h>
#include "ModuleControl.h"

// 全局开关（原 dylib 由卡密驱动，这里恒为 YES —— 这就是"不要卡密"的核心）
static inline BOOL AUGIsLicensed(void) { return YES; }

@interface AUGOverlayWindow : UIWindow
@end

@interface AUGOverlayView : UIView
@end

@interface AUGFloatingBall : UIView
@end

// 防截屏容器（对应原 HeeeNoScreenShotView）
@interface AUGSecureView : UIView
@property (nonatomic, strong) UITextField *decoyField;
@end

// 渲染循环入口
void AUGStartOverlay(void);
