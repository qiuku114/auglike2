//
//  Aimbot.mm —— 最近目标锁定 + 触摸注入自瞄
//
//  2D 游戏的自瞄 = 把「持续按住的手指」往目标方向慢慢推。
//  这里用 IOHIDEvent 合成触摸（dlopen 私有框架，不硬链接）。
//
//  流程：
//    AUGPickTarget()  在屏内球里挑离准心最近的一个
//    AUGAimStep()     算出方向，按平滑系数推进虚拟手指位置
//    AUGTouchMove()   把虚拟手指发出去（游戏收到后自己转角色朝向）
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <dlfcn.h>
#include <math.h>
#include <string.h>
#include <mach/mach_time.h>
#include "UnityBridge.h"
#include "AUGRender.h"
#include "ModuleControl.h"

/* ---------------- IOHID 私有接口 ---------------- */
typedef struct __IOHIDEvent *IOHIDEventRef;
typedef struct __IOHIDEventSystemClient *IOHIDEventSystemClientRef;

static IOHIDEventRef (*p_digitizerEvent)(CFAllocatorRef, uint64_t, uint32_t,
                                         uint32_t, uint32_t, double, double,
                                         double, double, double, double);
static void (*p_appendEvent)(IOHIDEventRef, IOHIDEventRef, uint32_t);
static IOHIDEventRef (*p_parentEvent)(IOHIDEventRef, uint32_t);
static void (*p_dispatchEvent)(IOHIDEventRef, uint32_t, uint32_t, IOHIDEventSystemClientRef);

static IOHIDEventRef gParent = NULL;
static IOHIDEventSystemClientRef gClient = NULL;
static int gPointerDown = 0;

static void AUGInitHID(void) {
    if (p_dispatchEvent) return;
    void *h = dlopen("/System/Library/PrivateFrameworks/IOHID.framework/IOHID", RTLD_LAZY);
    if (!h) return;
    p_digitizerEvent = dlsym(h, "IOHIDEventCreateDigitizerEvent");
    p_appendEvent    = dlsym(h, "IOHIDEventAppendEvent");
    p_parentEvent    = dlsym(h, "IOHIDEventCreateDigitizerFingerEvent");
    p_dispatchEvent  = dlsym(h, "IOHIDEventSystemClientDispatchEvent");
}

/* 发送一次手指位置（x,y 为屏幕点坐标） */
void AUGTouchMove(CGPoint p, BOOL down) {
    AUGInitHID();
    if (!p_dispatchEvent || !p_digitizerEvent) return;

    CGFloat scale = [UIScreen mainScreen].scale;
    // type 3 = finger；最后一对参数是 pressure/radius
    IOHIDEventRef ev =
        p_digitizerEvent(kCFAllocatorDefault, mach_absolute_time(),
                         3, 0, 1,
                         p.x * scale, p.y * scale,
                         down ? 1.0 : 0.0, 1.0, 0.0, 0.0);
    if (!ev) return;
    p_dispatchEvent(ev, 0, 0, NULL);
    CFRelease(ev);
    gPointerDown = down;
}

/* ---------------- 目标选择 ---------------- */
int AUGPickTarget(AUGEntity *list, int n, CGPoint center, float maxR, int *outIndex) {
    int best = -1;
    float bestD = maxR;
    for (int i = 0; i < n; i++) {
        if (!list[i].visible) continue;
        float dx = list[i].screen_x - center.x;
        float dy = list[i].screen_y - center.y;
        float d = sqrtf(dx * dx + dy * dy);
        if (d < bestD) { bestD = d; best = i; }
    }
    if (outIndex) *outIndex = best;
    return best >= 0;
}

/* ---------------- 每帧推进 ---------------- */
void AUGAimStep(ModuleControl *mc, AUGEntity *list, int n) {
    if (!mc->aimbot.on) { if (gPointerDown) AUGTouchMove(CGPointZero, NO); return; }

    CGRect scr = [UIScreen mainScreen].bounds;
    CGPoint center = CGPointMake(scr.size.width * .5f, scr.size.height * .5f);

    int idx = -1;
    if (!AUGPickTarget(list, n, center, mc->aimbot.f2, &idx)) return;

    AUGEntity *t = &list[idx];
    float dx = t->screen_x - center.x;
    float dy = t->screen_y - center.y;
    float d = sqrtf(dx * dx + dy * dy);
    if (d < 4.f) return;

    // 平滑：0 = 最平滑，1 = 瞬移
    float k = 0.15f + mc->aimbot.f3 * 0.85f;
    float speed = mc->aimbot.f1 * 0.1f * k;

    static CGPoint cur = {0, 0};
    if (!gPointerDown) { cur = center; gPointerDown = 1; }
    cur.x += dx * speed;
    cur.y += dy * speed;
    AUGTouchMove(cur, YES);
}
