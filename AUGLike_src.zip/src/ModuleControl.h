//
//  ModuleControl.h
//  AUGLike —— 还原自 AUG.dylib 的 Objective-C 类型编码：
//  ^{ModuleControl=Bii{MainSwitch=BBB}{PlayerSwitch=BBBBBBBBBBBBf{ImVec2=ff}}[14B]{AimbotController=BiifBffB}}
//
//  说明：结构体顺序严格按类型编码还原；对齐按 arm64 自然对齐。
//  真机上若发现字段错位，按实际 dump 微调 padding 即可。
//
#pragma once
#include <stdint.h>

typedef struct {
    float x;
    float y;
} AUGVec2;

typedef struct {
    bool a, b, c;
} MainSwitch;

typedef struct {
    bool  b[12];      // BBBBBBBBBBBB
    float f;          // f
    AUGVec2 v;        // {ImVec2}
} PlayerSwitch;

typedef struct {
    bool  on;         // B
    int   mode;       // i
    int   mode2;      // i
    float f1;         // f
    bool  b1;         // B
    float f2;         // f
    float f3;         // f
    bool  b2;         // B
} AimbotController;

typedef struct {
    bool  enabled;        // B
    int   f1;             // i
    int   f2;             // i
    MainSwitch      main;
    PlayerSwitch    player;
    uint8_t         reserved[14];
    AimbotController aimbot;
} ModuleControl;

// 全局单例（对应原 dylib 里 mi/moduleControl 的那份状态）
extern ModuleControl gMC;
