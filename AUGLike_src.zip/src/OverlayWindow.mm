//
//  OverlayWindow.mm —— 叠加窗口
//
//  关键：默认不拦截触摸，只有落在菜单区域/悬浮球上的触摸才吃掉，
//  其余全部透传给游戏（原包 _0x8C2F4D71 的 hitTest 就是这个作用）。
//
#import "AUGLike.h"

@implementation AUGOverlayWindow

- (BOOL)canBecomeKeyWindow { return NO; }

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *v = [super hitTest:point withEvent:event];
    if (v == self.rootViewController.view) {
        // 只有真正挂在菜单上的子视图才算命中
        for (UIView *sub in self.rootViewController.view.subviews) {
            if ([sub isKindOfClass:[AUGFloatingBall class]]) {
                CGPoint p = [sub convertPoint:point fromView:self];
                if (CGRectContainsPoint(sub.bounds, p)) return sub;
            }
        }
        return nil;   // 透传给游戏
    }
    return v;
}

@end
