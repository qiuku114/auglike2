#!/bin/bash
# AUGLike 一键构建 —— 在 macOS 上执行
#
#   bash build_all.sh                        # 只编译，输出 dylib
#   bash build_all.sh ~/Downloads/AUG.ipa    # 编译 + 直接产出可签名的 IPA
#
set -e

WORK="$HOME/auglike-build"
mkdir -p "$WORK"
cd "$WORK"

echo "==> 1/5 准备 Theos"
if [ ! -d theos ]; then
  git clone --recursive --depth 1 https://github.com/theos/theos.git theos
fi
export THEOS="$WORK/theos"

echo "==> 2/5 准备 iOS SDK"
mkdir -p "$THEOS/sdks"
if [ ! -d "$THEOS/sdks/iPhoneOS16.5.sdk" ]; then
  SDK_URL=$(curl -sL https://api.github.com/repos/theos/sdks/releases/latest \
    | python3 -c "import sys,json;d=json.load(sys.stdin);print([a['browser_download_url'] for a in d['assets'] if 'iPhoneOS16.5.sdk' in a['name']][0])")
  echo "    SDK: $SDK_URL"
  curl -L -o sdk.tar.xz "$SDK_URL"
  tar -xJf sdk.tar.xz -C "$THEOS/sdks"
fi

echo "==> 3/5 准备 ImGui"
if [ ! -d imgui ]; then
  git clone --depth 1 --branch v1.90.9 https://github.com/ocornut/imgui.git imgui
fi

echo "==> 4/5 解包源码并编译"
SRC_ZIP="${AUGLIKE_SRC:-$HOME/Downloads/AUGLike_src.zip}"
if [ -f "$SRC_ZIP" ]; then
  unzip -o -q "$SRC_ZIP"
elif [ ! -f Makefile ]; then
  echo "找不到源码：把 AUGLike_src.zip 放到 ~/Downloads 或设 AUGLIKE_SRC=<路径>"
  exit 1
fi
make -j4 || make

DYLIB=$(find .theos -name "AUGLike.dylib" | head -1)
if [ -z "$DYLIB" ]; then echo "编译失败，没找到 dylib"; exit 1; fi
echo "    dylib: $WORK/$DYLIB"

echo "==> 5/5 打包（可选）"
if [ -n "$1" ]; then
  rm -rf repack && mkdir repack && cd repack
  unzip -o -q "$1"
  cp "../$DYLIB" Payload/balls.app/AUG.dylib
  zip -qr ../AUGLike.ipa Payload
  cd ..
  echo "    IPA: $WORK/AUGLike.ipa"
  echo "    下一步：用全能签/轻松签签这个 IPA，注意 AUG.dylib 必须一起签"
else
  echo "    只出 dylib。要出 IPA：bash build_all.sh /路径/原包.ipa"
fi

echo "==> 完成"
